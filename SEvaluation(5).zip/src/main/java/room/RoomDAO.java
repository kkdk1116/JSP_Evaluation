package room;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import util.DatabaseUtil;

public class RoomDAO {

	//private Connection conn;
	//private PreparedStatement pstmt;
	//private ResultSet rs;
	

	public int insert(RoomDTO roomDTO) {	
		String SQL = "INSERT INTO ROOM VALUES (?, ?, ?, ?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DatabaseUtil.getConnection();
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, roomDTO.getResvNo());
			pstmt.setString(2, roomDTO.getEmpNo());
			pstmt.setString(3, roomDTO.getResvDate());
			pstmt.setString(4, roomDTO.getEmpNo());
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try { if(conn != null) conn.close(); } catch (Exception e) {e.printStackTrace();}
			try { if(pstmt != null) pstmt.close(); } catch (Exception e) {e.printStackTrace();}
			try { if(rs != null) rs.close(); } catch (Exception e) {e.printStackTrace();}
		}
		return -1; // 데이터베이스 오류
	}

	
	
	
	
}
