function addCheck() {
	if(frm.resvNo.value.length==0) {
		alert("예약번호가 입력되지 않았습니다!");
		frm.resvNo.focus();
		return false;
	}
	
	else if(frm.empNo.value.length==0) {
		alert("회원번호가 입력되지 않았습니다!");
		frm.empNo.focus();
		return false;
	}
	
	else if(frm.resvDate.value.length==0) {
		alert("예약날짜가 입력되지 않았습니다!");
		frm.resvDate.focus();
		return false;
	}
	
	else if(frm.seatNo.value.length==0) {
		alert("숙박번호가 입력되지 않았습니다!");
		frm.seatNo.focus();
		return false;
	}
	
	else
	alert("숙박예약정보가 등록되었습니다!");
	document.frm.submit();
	return true;
}

function res() {
	alert("정보를 지우고 처음부터 다시 입력합니다");
	document.frm.reset();
	
}

function search() {
	if(frm2.empNo.value.length==0) {
		alert("회원번호가 입력되지 않았습니다!");
		frm2.empNo.focus();
		return false;
	}
	else
	document.frm2.submit();
	return true;
};
