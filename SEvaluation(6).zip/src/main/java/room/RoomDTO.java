package room;

public class RoomDTO {

	String resvNo;
	String empNo;
	String resvDate;
	String seatNo;
	
	public String getResvNo() {
		return resvNo;
	}



	public void setResvNo(String resvNo) {
		this.resvNo = resvNo;
	}



	public String getEmpNo() {
		return empNo;
	}



	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}



	public String getResvDate() {
		return resvDate;
	}



	public void setResvDate(String resvDate) {
		this.resvDate = resvDate;
	}



	public String getSeatNo() {
		return seatNo;
	}



	public void setSeatNo(String seatNo) {
		this.seatNo = seatNo;
	}



	public RoomDTO(String resvNo, String empNo, String resvDate, String seatNo) {
		super();
		this.resvNo = resvNo;
		this.empNo = empNo;
		this.resvDate = resvDate;
		this.seatNo = seatNo;
	}

}
